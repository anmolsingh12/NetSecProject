import java.sql.*;
public class StudentDAO {
public boolean insertRecord(int id,String name,int age)
{
	boolean result=true;
	try{
		Class.forName("com.mysql.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/test";
		String user="root";
		String pass="root";
		Connection con=DriverManager.getConnection(url,user,pass);
		PreparedStatement ps=con.prepareStatement("Insert into student2 values(?,?,?)");
		ps.setInt(1, id);
		ps.setString(2, name);
		ps.setInt(3, age);
		ps.executeUpdate();
	}catch(Exception ex)
	{
		ex.printStackTrace();
		result=false;
	}
	return result;
}
}
